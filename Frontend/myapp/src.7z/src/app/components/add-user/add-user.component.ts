import { Component } from '@angular/core';
import { UsuarioService } from '../../services/usuario.service';
import { FormsModule } from '@angular/forms'; // Asegúrate de importar FormsModule

@Component({
  selector: 'app-add-user',
  standalone: true,
  imports: [FormsModule], // Importa FormsModule aquí
  template: `
    <h2>Agregar Usuario</h2>
    <form (ngSubmit)="addUser()">
      <input type="text" [(ngModel)]="newUser.nombre" name="nombre" placeholder="Nombre" required>
      <input type="text" [(ngModel)]="newUser.apellido" name="apellido" placeholder="Apellido" required>
      <input type="text" [(ngModel)]="newUser.direccion" name="direccion" placeholder="Dirección" required>
      <input type="email" [(ngModel)]="newUser.email" name="email" placeholder="Email" required>
      <input type="password" [(ngModel)]="newUser.contrasena" name="contrasena" placeholder="Contraseña" required>
      <button type="submit">Agregar Usuario</button>
    </form>
  `
})
export class AddUserComponent {
  newUser: any = {};

  constructor(private usuarioService: UsuarioService) {}

  addUser() {
    this.usuarioService.postUser(this.newUser).subscribe({
      next: (response) => {
        console.log('Usuario agregado:', response);
      },
      error: (error) => {
        console.error('Error al agregar el usuario:', error);
      }
    });
  }
}

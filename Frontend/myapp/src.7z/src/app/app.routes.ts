import { Routes } from '@angular/router';
import { UsersComponent } from './components/users/users.component';
import { ContenidoComponent } from './components/contenido/contenido.component';
import { InicioComponent } from './components/inicio/inicio.component';
import { AddUserComponent } from './components/add-user/add-user.component';

export const routes: Routes = [
  { path: 'usuario', component: UsersComponent },
  { path: 'inicio', component: InicioComponent },
  { path: 'contenido', component: ContenidoComponent },
  { path: 'agregar-usuario', component: AddUserComponent },
  { path: '', redirectTo: '/inicio', pathMatch: 'full' },
];
